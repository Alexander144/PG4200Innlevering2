# Grunnleggende funksjonalitet

# Begrensning av indekseringen

# Traverseringsorden

# Effektivisering
